import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-documentation-links',
  templateUrl: './documentation-links.component.html',
  styleUrls: ['./documentation-links.component.css']
})
export class DocumentationLinksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
