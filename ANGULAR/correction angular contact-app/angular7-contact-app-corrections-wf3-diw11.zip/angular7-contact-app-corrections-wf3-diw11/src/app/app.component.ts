import { Component } from '@angular/core';
import { ContactsService } from "./services/contacts.service";
// import { ActivatedRoute, Router, Routes, RouterModule, RoutesRecognized, NavigationEnd} from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'app';
  

  ngOnInit() {
    

  }

 
}
