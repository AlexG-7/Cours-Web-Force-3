<!-- <form action="#">
    <h3>Inscription</h3>
    <label>Pseudo:</label>
    <input type="text" value="jules">
    <label>Email</label>
    <input type="text" value="jules@mail.com">
    <label>Mot de passe</label>
    <input type="password" value="azerty123">
    <input type="submit" value="Inscription">
</form> -->

<form action="#">
    <h3>Connexion</h3>
    <label>Pseudo/email:</label>
    <input type="text" value="jules@mail.com">
    <label>Mot de passe</label>
    <input type="password" value="azerty123">
    <input type="submit" value="Connexion">
</form>