# 4.2 Exercices (Pt. 3-4)

<br>
>**1)** Afficher la liste des emprunts contenant:
 - le prénom de l'abonné
 - la date de sortie formatée en français (<code class="prettyprint">JJ/MM/AAAA</code>)
 - le titre du livre


<br>
>**2)** Afficher la durée (en jours) de chaque emprunt (pour les livres qui ont été rendus):
 - titre du livre
 - nombre de jours tels que: <code class="prettyprint">N jours</code>


>**Bonus:** afficher aussi depuis combien de jours sont empruntés les livres qui n'ont pas encore été rendus.


<br>
>**3)** Afficher la liste des livres et le nombre de fois qu'ils ont été empruntés, classés par nombre d'emprunts en ordre décroissant.


<br>
>**4)** Afficher la liste des livres disponibles à la bibliotheque.


<br>
>**5)** Afficher le nombre d'emprunts par an.


<br>
>**6)** Afficher la liste des livres classés du titre le plus long au plus court, ainsi que le nom de l'auteur avec uniquement la 1e lettre en majuscule.


<br>
>**7)** Afficher le nombre d'emprunts par auteur.


>**8)** Si les livres devaient être rendus au bout de 2 mois, afficher les dates auxquelles les livres qui n'ont pas été rendus auraient dû l'être.


>**Bonus:** Indiquez aussi depuis combien de jours les abonnés sont en retard pour rendre leurs livres.


<br>
>**9)** Afficher la liste des emprunts contenant:
 - le prénom de l'abonné
 - le numéro d'emprunt pour l'abonné (1er, 2e, ... emprunt par l'abonné)
 - la date d'emprunt
 - le titre du livre
 - le numéro d'emprunt pour le livre (1e, 2e, ... fois que le livre est emprunté)


<br><br>
-----
**Précédent:** [4.1 Fonctions prédéfinies](?file=15_fonctions_predefinies.md)
<!-- **Suivant:** [4.2 Fonctions utilisateur](?file=15_fonctions_predefinies.md) -->